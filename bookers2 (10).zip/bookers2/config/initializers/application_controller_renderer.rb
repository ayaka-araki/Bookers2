# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '828e3be837b1968b219323e990d3ffa461bb6b86bc9a63ebfb042602b6a8b174f57aff58086a9fea231f7442836760713d8b5348dca57e6f63a6fd1dc85154b5'