class PostImagesController < ApplicationController
end
